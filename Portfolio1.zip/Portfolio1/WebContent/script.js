let backside;
let First = true;
let cardFirst;
let countUnit = 0;
let matchedCount = 0;

let img_arr = [
    "card1", "card2", "card3", "card4", "card5", "card6", "card7", "card8", "card9", "card10",
    "card11", "card12", "card13", "card14", "card15", "card16", "card17", "card18", "card19", "card20"
	];
let img_tag_arr = [];
	for(let i = 0; i < 20; i++){
    	img_tag_arr.push("<img src='" + img_arr[i] + ".jpg'>")
	}

	window.onload = function() {
    let arr = [];
    for(let i = 0; i < 20; i++) {
		arr.push(i);
        arr.push(i);
    }
 
    shuffle(arr);
    let memorygame = document.getElementById("memorygame");

    for(i = 0; i < 40; i++) {
        let div = document.createElement("div");
        div.className = "card back";
        div.number = arr[i];
        div.onclick = turn;
        memorygame.appendChild(div);
    	}	
    	matchedPairs = arr.length / 2;
	}

	function shuffle(arr) {
    	let j = arr.length;
    	while(j) {
        	i = Math.floor(Math.random() * j--);
        	[arr[j], arr[i]] = [arr[i], arr[j]]
    	}
    	return arr;
		}

	function turn(k) {
    	let div = k.target;
    	if(backside) return;
    	if(div.className.includes("finish")) return;
    	
    	if(div.innerHTML == "") {
        	div.className = "card";
        	div.innerHTML = img_tag_arr[div.number];
        	countUnit++;
    	} else {
        	return
    	}
    	if(First) {
        	cardFirst = div;
        	First = false;
    	} else {
        	if(cardFirst.number == div.number) {
            	matchedPairs--;
            	if(matchedPairs === 0){
					alert("全てのカードが揃いました！回数：" + countUnit);
				}
            	backside = setTimeout(function() {
                	div.className = "card finish";
                	cardFirst.className = "card finish";
                	backside = NaN;
					}, 600)
			}else {
            	backside = setTimeout(function() {
                	div.className = "card back";
                	div.innerHTML = "";
                	cardFirst.className = "card back";
                	cardFirst.innerHTML = "";
                	cardFirst = null;
                	backside = NaN;
					}, 600);
			}
        First = true;
	}
}
function gameFinished(countUnit) {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "/RankingServlet", true);
    xhr.setRequestHeader("Content-Type", "application/json");

    let data = {
        countUnit: countUnit
    };

    xhr.send(JSON.stringify(data));

    xhr.onload = function() {
        if (xhr.status == 200) {
            let response = JSON.parse(xhr.responseText);
            if (response.success) {
                alert("ランキングに記録されました！");
            } else {
                alert("ランキングの記録に失敗しました。");
            }
        }
    }
}