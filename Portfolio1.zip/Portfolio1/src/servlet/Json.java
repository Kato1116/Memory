package servlet;

import java.util.List;

import servlet.RankingServlet.RankingDto;

public class Json {

	public String toJson(List<RankingDto> rankingList) {
		// TODO Auto-generated method stub
		return null;
	}

	public String toJson1(List<RankingDto> rankingList) {
		// TODO Auto-generated method stub
		return null;
	}

}
