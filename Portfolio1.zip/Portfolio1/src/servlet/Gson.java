package servlet;

import java.util.List;

import servlet.RankingServlet.RankingDto;

public class Gson {

	public String toJson(List<RankingDto> rankingList) {
		// TODO Auto-generated method stub
		return null;
	}

}
