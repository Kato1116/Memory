package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RankingServlet")
public class RankingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Connection con;

    public class RankingDto {
        private String name;
        private int value;
        
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public int getValue() {
            return value;
        }
        public void setValue(int value) {
            this.value = value;
        }
    }

    
    @Override
    public void init() throws ServletException {
        String url = "jdbc:mysql://localhost:3306/memory?serverTimezone=UTC";
        String user = "root";
        String pass = "root";
        try {
            con = DriverManager.getConnection(url, user, pass);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("Connection success!");
    }
    
    public void close() {
		try {
			if(con != null) con.close(); 
		}catch(SQLException e){
			e.printStackTrace();
		}
	}

    @Override
    public void destroy() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<RankingDto> getListAll() throws SQLException {
        String sql = "SELECT * FROM ranking";
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<RankingDto> list = new ArrayList<>();

        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                RankingDto dto = new RankingDto();
                dto.setName(rs.getString("name"));
                dto.setValue(rs.getInt("count"));
                list.add(dto);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        }

        Comparator<RankingDto> comparator = Comparator.comparing(RankingDto::getName).reversed();
        return list.stream().sorted(comparator).collect(Collectors.toList());
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<RankingDto> rankingList = getListAll();

            String json = new Json().toJson(rankingList);

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(json);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
